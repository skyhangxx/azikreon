'use strict';

const telegramLink = document.querySelector('[data-telegram]');
if (telegramLink && window.AKIZ_CONFIG?.telegramUrl) { telegramLink.href = window.AKIZ_CONFIG.telegramUrl; telegramLink.hidden = false; }
const stateOnThanks = JSON.parse(sessionStorage.getItem('akiz_test_state') || 'null');
if (stateOnThanks?.complete) document.querySelector('[data-test-thanks]').hidden = false;
